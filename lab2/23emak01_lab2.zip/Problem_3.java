/* 
 * Modul 2
 * Problem_3.java
 * Emil Åkerman
 * 2024-09-02
 * https://github.com/emilakerman/java-work
*/
public class Problem_3 {
    public static void main(String[] args) {
        System.out.println("Utskrift 1: ");
        System.out.println(5 / 2);
        System.out.println("Utskrift 2: ");
        System.out.println(5.0 / 2);
    }
}
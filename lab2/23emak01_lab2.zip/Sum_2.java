/* 
 * Modul 2
 * Sum_2.java
 * Emil Åkerman
 * 2024-09-02
 * https://github.com/emilakerman/java-work
*/
public class Sum_2 {
    public static void main(String[] args) {
        int k = 6;
        int s = k + (k + 1) + (k + 2) + (k + 3) + (k + 4) + (k + 5) + (k + 6) + (k + 7) + (k + 8) + (k + 9);
        System.out.println(s);
    }
}
/* 
 * Modul 2
 * Sum.java
 * Emil Åkerman
 * 2024-09-02
 * https://github.com/emilakerman/java-work
*/
public class Sum {
    public static void main(String[] args) {
        System.out.println(11 + 12 + 13 + 14 + 15 + 16 + 17 + 18 + 19 + 20);
    }
}

/* 
 * Modul 2
 * Problem_2.java
 * Emil Åkerman
 * 2024-09-02
 * https://github.com/emilakerman/java-work
*/
public class Problem_2 {
    public static void main(String[] args) {
        double a = 1.5;
        double b = 15;
        char c = 'u';
        a = a + c;

        System.out.println(a);
        System.out.println(b);
        System.out.println(c);
    }
}
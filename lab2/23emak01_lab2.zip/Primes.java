/* 
 * Modul 2
 * Primes.java
 * Emil Åkerman
 * 2024-09-02
 * https://github.com/emilakerman/java-work
*/

public class Primes {
    public static void main(String[] args) {
        System.out.println("3 5 7 11 13 17 19 23");
    }
}